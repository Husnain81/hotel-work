<div id="header">
    <img src="images/blue-chair-background-lounge-pool-2.jpg" alt="">
    <h4>Hi! <span><?php echo $_SESSION["username"]; ?></span></h4>
</div>