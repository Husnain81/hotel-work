<?php include 'inc/header.php' ?>

<?php include 'inc/authentication.php' ?>

<?php include 'inc/bg-header.php' ?>

      <div class=" mx-auto p-4 bg-card rounded-lg">
        <h2 class="text-lg font-semibold text-foreground text-center">Vip Services</h2>
        <div class="mt-4">
          <button href="#" class=" border w-full text-left p-2 rounded mb-3 border-border hover:bg-muted block">
            <div class="p-4 bg-card text-card-foreground">
                <ol class="list-disc list-inside space-y-2">
                  <li> Dear VIP 1 The Commision rate is 1%.</li>
                  <li> Dear VIP 1 The Commision rate is 2%.</li>
                  <li> Dear VIP 1 The Commision rate is 4%.</li>
                  <li> Dear VIP 1 The Commision rate is 7%.</li>
                </ol>
              </div>
          </button>
        </div>
      </div>
</body>
</html>