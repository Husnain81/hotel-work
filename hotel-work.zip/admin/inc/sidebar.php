<div class="sidebar">
        <a href="index.php">
        <div class="admindek">
          <img src="assets/images/logo-light.5273b2fd.png" alt="LOGO" style="color: #fff;" />
        </div>
        </a>
        <div class="navigation sidebar-headings">
            <h5>Dashboard</h5>
            <div class="sidebar-links-container">
                <div class="sidebar-links">
                    <button class="dropdown-btn flex">
                        <div class="flex">
                            <i class="fa-regular fa-user"></i>
                            <h5>Member Management</h5>
                        </div>
                        <div class="p-x">
                            <i class="fa-regular fa-chevron-down"></i>
                        </div>
                    </button>
                    <div class="dropdown-container">
                        <a href="member-list.php">Member List</a>
                    </div>
                </div>
                <div class="sidebar-links">
                    <button class="dropdown-btn flex">
                        <div class="flex">
                            <i class="fa-regular fa-clipboard"></i>
                            <h5>Transaction Management</h5>
                        </div>
                        <div class="p-x">
                            <i class="fa-regular fa-chevron-down"></i>
                        </div>
                    </button>
                    <div class="dropdown-container">
                        <a href="order-list.php">Order List</a>
                        <a href="withdraw-list.php">Withdrawl List</a>
                        <a href="recharge-list.php">Recharge List</a>
                        <a href="transaction-flow.php">Transaction Flow</a>
                    </div>
                </div>
              
            </div>
        </div>
    </div>