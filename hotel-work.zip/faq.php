<?php include 'inc/header.php' ?>

<?php include 'inc/authentication.php' ?>

<?php include 'inc/bg-header.php' ?>

    <div class=" mx-auto p-4 bg-card rounded-lg">
        <h2 class="text-lg font-semibold text-foreground text-center">FAQ</h2>
        <div class="mt-4">
            <button href="#" class=" border w-full text-left p-2 rounded mb-3 border-border hover:bg-muted block">
                <div class="p-4 bg-card text-card-foreground">
                    <span>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore excepturi eius assumenda
                        accusamus voluptas odit, veniam suscipit, cupiditate natus ea dolores! Iure facilis autem
                        delectus aut consectetur, sapiente ratione quos cupiditate eligendi voluptate, fugiat corporis
                        laborum vitae placeat excepturi eius, fugit voluptatum! Veritatis iure tempore rem repudiandae
                        minus quidem id.</span>
                </div>
            </button>
        </div>
    </div>
</body>

</html>